import {
  Info,
  GraduationCap,
  Clock,
  MapPin,
  BookOpen,
  Award,
  Building2,
  Phone,
  Wifi,
  Library,
  Dumbbell,
  HeartPulse,
} from 'lucide-react';
import { PageHeader } from '@/components/ui';

const INFO_SECTIONS = [
  {
    icon: GraduationCap,
    title: 'About Government Engineering College, Buxar',
    color: 'from-teal-500 to-cyan-600',
    content:
      'Government Engineering College (GEC), Buxar is a Government of Bihar engineering college under the Science, Technology and Technical Education Department. The college started its first academic session in 2019 at Bakhtiyarpur College of Engineering and shifted to its permanent campus at Mahdah, Itarhi Road, adjacent to the police line, Buxar on 15 April 2024.',
  },
  {
    icon: BookOpen,
    title: 'Academic Departments',
    color: 'from-purple-500 to-pink-600',
    content:
      'GEC Buxar has Civil Engineering, Mechanical Engineering, Electrical Engineering, Electronics & Communication Engineering, Computer Science & Engineering, and Applied Science & Humanities. The official history page lists an intake of 60 each for Civil, Mechanical, Electrical and Electronics & Communication, and 120 for Computer Science & Engineering.',
  },
  {
    icon: Building2,
    title: 'Campus Facilities',
    color: 'from-blue-500 to-indigo-600',
    content:
      'The official website lists a Computer Center, Central Library, Hostels, Sports Facilities, Medical Facilities, Guest House, Gymnasium, Bank, Club and campus Wi-Fi. The Computer Center page describes computing facilities, internet connectivity, a campus-wide network and a network lab. The Central Library reports more than 25,000 books and more than 5,000 computer-related books.',
  },
  {
    icon: Award,
    title: 'Training & Placement',
    color: 'from-orange-500 to-amber-500',
    content:
      'The official 2021–2025 placement record reports 76 students placed. Branch-wise placement data reports 15 Civil students, 23 ECE students, 23 Electrical students and 15 Mechanical students placed. The highest package reported for ECE, Electrical and Mechanical was ₹10 LPA, while Civil reported ₹5 LPA.',
  },
];

const QUICK_FACTS = [
  { label: 'First Academic Session', value: '2019', icon: Clock },
  { label: 'Permanent Campus', value: '2024', icon: MapPin },
  { label: 'CSE Intake', value: '120', icon: GraduationCap },
  { label: 'Library Books', value: '25,000+', icon: Library },
];

const DEPARTMENTS = [
  'Civil Engineering',
  'Mechanical Engineering',
  'Electrical Engineering',
  'Electronics & Communication Engineering',
  'Computer Science & Engineering',
  'Applied Science & Humanities',
];

const FACILITIES = [
  { label: 'Computer Center', icon: Building2 },
  { label: 'Central Library', icon: Library },
  { label: 'Hostels', icon: Building2 },
  { label: 'Sports Facilities', icon: Dumbbell },
  { label: 'Medical Facilities', icon: HeartPulse },
  { label: 'Gymnasium', icon: Dumbbell },
  { label: 'Campus Wi-Fi', icon: Wifi },
];

export default function CollegeInfoPage() {
  return (
    <div>
      <PageHeader
        title="GEC Buxar Information"
        subtitle="Official college information, departments, facilities and placement highlights."
        icon={<Info className="w-7 h-7" />}
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {QUICK_FACTS.map((fact) => {
            const Icon = fact.icon;
            return (
              <div key={fact.label} className="bg-white rounded-2xl p-5 border border-slate-200 text-center">
                <div className="w-10 h-10 mx-auto rounded-xl bg-teal-50 flex items-center justify-center mb-3">
                  <Icon className="w-5 h-5 text-teal-600" />
                </div>
                <div className="text-2xl font-bold text-slate-900">{fact.value}</div>
                <div className="text-sm text-slate-500 mt-0.5">{fact.label}</div>
              </div>
            );
          })}
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6 mb-8">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center flex-shrink-0">
              <MapPin className="w-6 h-6 text-teal-600" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Campus Address</h2>
              <p className="text-slate-600 mt-2 leading-relaxed">
                Village- Mahdah, Itarhi Road, P.O.- Gajadhar Ganj, Near Police Line,
                Buxar, Bihar – 802103
              </p>
              <a
                href="https://www.gecbuxar.ac.in/"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 mt-3 text-sm font-semibold text-teal-600 hover:text-teal-700"
              >
                Visit official GEC Buxar website →
              </a>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {INFO_SECTIONS.map((section) => {
            const Icon = section.icon;
            return (
              <div key={section.title} className="bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-md transition-shadow">
                <div className="flex flex-col sm:flex-row">
                  <div className={`sm:w-2 bg-gradient-to-b ${section.color}`} />
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${section.color} flex items-center justify-center`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <h2 className="text-xl font-bold text-slate-900">{section.title}</h2>
                    </div>
                    <p className="text-slate-600 leading-relaxed">{section.content}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-8 bg-white rounded-2xl border border-slate-200 p-6">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Departments</h2>
          <div className="grid sm:grid-cols-2 gap-3">
            {DEPARTMENTS.map((department) => (
              <div key={department} className="flex items-center gap-3 rounded-xl bg-slate-50 px-4 py-3">
                <BookOpen className="w-4 h-4 text-teal-600 flex-shrink-0" />
                <span className="text-sm font-medium text-slate-700">{department}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 bg-white rounded-2xl border border-slate-200 p-6">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Facilities listed by GEC Buxar</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {FACILITIES.map((facility) => {
              const Icon = facility.icon;
              return (
                <div key={facility.label} className="flex items-center gap-2 rounded-xl border border-slate-100 px-3 py-3">
                  <Icon className="w-4 h-4 text-teal-600" />
                  <span className="text-sm text-slate-700">{facility.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-8 bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl p-6 sm:p-8 text-white">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Phone className="w-5 h-5 text-teal-400" />
            </div>
            <h2 className="text-xl font-bold">College Contact</h2>
          </div>
          <a href="tel:06183297194" className="inline-flex items-center gap-2 font-semibold text-white hover:text-teal-300">
            <Phone className="w-4 h-4 text-teal-400" />
            06183-297194
          </a>
          <p className="text-sm text-slate-300 mt-3">
            For official notices and contact details, use the GEC Buxar website.
          </p>
        </div>
      </div>
    </div>
  );
}
