/*
  GEC Buxar official content seed
  Source: https://www.gecbuxar.ac.in/
  Seeded from official public pages available on 24 Aug 2026.
*/

INSERT INTO notices (title, body, category, priority, posted_at)
SELECT v.title, v.body, v.category, v.priority, v.posted_at::timestamptz
FROM (VALUES
  ('Regarding Obtaining Copies of Evaluated Answer Booklets for B.Tech 3rd & 5th Semester Examinations – 2025.',
   'Official notice published by GEC Buxar on 23 Aug 2026. See the official notice page for the attached document.',
   'academic','high','2026-08-23T00:00:00+05:30'),
  ('Regarding Admit Card for Supplementary Examination',
   'Official notice published by GEC Buxar on 23 Aug 2026.',
   'academic','high','2026-08-23T00:00:00+05:30'),
  ('Regarding 4th SEM and 6th SEM MID SEM Exam Programme',
   'Revised mid-semester examination programme published by GEC Buxar on 12 Aug 2026.',
   'academic','high','2026-08-12T00:00:00+05:30'),
  ('Regarding Rescheduling of Lectures due to MID SEM exam',
   'Official lecture rescheduling notice published on 12 Aug 2026.',
   'academic','normal','2026-08-12T00:00:00+05:30'),
  ('Regarding Mid Semester exam of B.Tech 4th and 6th SEM',
   'Official mid-semester examination notice published on 08 Aug 2026.',
   'academic','high','2026-08-08T00:00:00+05:30'),
  ('SUPPLEMENTARY EXAMINATION: Regarding 1st to 8th Semester Supplementary Examination 2026',
   'Official supplementary examination notice published on 06 Aug 2026.',
   'academic','high','2026-08-06T00:00:00+05:30'),
  ('Walk-in-interview for Guest Assistant Professor and Guest Technical Lab Assistant',
   'Advertisement No. GEC/BUX/ADV/2026-27/03, published on 29 Jul 2026.',
   'general','normal','2026-07-29T00:00:00+05:30'),
  ('2026-30 Batch Time Table',
   'First Semester timetable for the 2026-30 batch. Class commencement date: 28/07/2026.',
   'academic','high','2026-07-27T00:00:00+05:30'),
  ('Hostel Allotment Notice for 2026-30 Batch',
   'Hostel allotment notice for newly admitted 2026-30 batch students, published on 27 Jul 2026.',
   'hostel','high','2026-07-27T00:00:00+05:30'),
  ('Admission in B.Tech (Lateral Entry) course for the session 2026-29',
   'Official lateral-entry admission notice published on 25 Jul 2026.',
   'academic','normal','2026-07-25T00:00:00+05:30')
) AS v(title,body,category,priority,posted_at)
WHERE NOT EXISTS (
  SELECT 1 FROM notices n WHERE n.title = v.title
);

INSERT INTO contacts (name, role, department, phone, email, category, priority)
SELECT v.name, v.role, v.department, v.phone, NULL, 'office', v.priority
FROM (VALUES
  ('Prof. (Dr.) Ram Naresh Rai','Principal','Administration','8974443620',100),
  ('Dr. Shyam Lal','Dean Academic','Academic Office','9899779841',95),
  ('Dr Ravindra Nath Yadav','Registrar and Admission In-charge','Academic Office','9450320652',90),
  ('Mr. Gaurav Parmar','Examination Controller','Examination Section','8709554686',85),
  ('Dr. Anjini Kumar Tiwary','HOD, Electronics & Communication Engineering','ECE','7250559321',80),
  ('Dr. Utkarsh Raj','HOD, Electrical Engineering','Electrical Engineering','7992407629',79),
  ('Dr. Jitendra Pratap Singh','HOD, Civil Engineering','Civil Engineering','8303160240',78),
  ('Dr. Rina Kumari','HOD, Computer Science & Engineering','Computer Science & Engineering','9472850982',77),
  ('Dr. Ramdayal Singh Kushwaha','HOD, Applied Science & Humanities','Applied Science & Humanities','8076562709',76),
  ('Prof. (Dr.) Ram Naresh Rai','HOD, Mechanical Engineering','Mechanical Engineering','8974443620',75)
) AS v(name,role,department,phone,priority)
WHERE NOT EXISTS (
  SELECT 1 FROM contacts c WHERE c.name = v.name AND c.role = v.role
);

INSERT INTO contacts (name, role, department, phone, email, category, priority)
SELECT 'GEC Buxar Main Office', 'College Contact', 'Administration', '06183297194', NULL, 'office', 110
WHERE NOT EXISTS (
  SELECT 1 FROM contacts c WHERE c.name = 'GEC Buxar Main Office'
);

INSERT INTO clubs (name, category, description, meeting_day, contact)
SELECT v.name, v.category, v.description, NULL, NULL
FROM (VALUES
  ('Coding Club','technical','A student community for coding, coding competitions, hackathons, workshops and coding challenges.'),
  ('Robotics Club','technical','A student community focused on robotics, innovation and engineering technology.'),
  ('Fine Arts Club','cultural','A creative student space for painting, drawing, sculpture and other visual art forms.')
) AS v(name,category,description)
WHERE NOT EXISTS (
  SELECT 1 FROM clubs c WHERE c.name = v.name
);

INSERT INTO campus_locations (name, block, floor, room, category, description, landmark)
SELECT v.name, v.block, NULL, NULL, v.category, v.description, 'Permanent GEC Buxar campus, Mahdah'
FROM (VALUES
  ('Government Engineering College, Buxar','Permanent Campus','block','Government Engineering College, Buxar permanent campus at Mahdah, Itarhi Road, adjacent to the police line.'),
  ('Central Library','Permanent Campus','facility','Central Library with 25,000+ books and an E-Resource Section.'),
  ('Computer Center','Permanent Campus','facility','Computing facility, internet connectivity, campus-wide network and network lab.'),
  ('Hostels','Permanent Campus','facility','Hostel facilities are listed by the official GEC Buxar website.'),
  ('Sports Facilities','Permanent Campus','facility','Sports facilities listed by the official GEC Buxar website.'),
  ('Medical Facilities','Permanent Campus','facility','Medical facilities listed by the official GEC Buxar website.'),
  ('Gymnasium','Permanent Campus','facility','Gymnasium listed by the official GEC Buxar website.'),
  ('Campus Wi-Fi','Permanent Campus','facility','Campus-wide Wi-Fi is listed by the official GEC Buxar website.')
) AS v(name,block,category,description)
WHERE NOT EXISTS (
  SELECT 1 FROM campus_locations l WHERE l.name = v.name
);
